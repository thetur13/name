<?php

include 'mysql.php';
include 'functions.php';

if (isset($_GET['act'] == 'aaa'))
{

} elseif ($_GET['act'] == 'bbb')
{
	
}